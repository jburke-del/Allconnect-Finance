## What changed

Briefly describe the change.

## Type

- [ ] New KPI definition
- [ ] Change to an existing KPI definition
- [ ] Data documentation
- [ ] Tool or runbook
- [ ] Other

## Definition of done (KPI changes)

- [ ] YAML frontmatter complete (id, name, domain, formula, grain, source, owner,
      favorable_direction, status, last_reviewed)
- [ ] `status` set correctly (draft / approved / deprecated)
- [ ] `favorable_direction` stated in words in the Interpretation section
- [ ] Caveats and relevant known-issue links included
- [ ] Reference query included
- [ ] `last_reviewed` updated to today
- [ ] Metric owner tagged for review

## Validation

- [ ] `python scripts/validate_kb.py` passes locally
